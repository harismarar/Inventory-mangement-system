from tkinter import *
from tkinter import ttk, messagebox
from tkcalendar import DateEntry
import sqlite3
import pandas as pd

class ReportsClass:
    def __init__(self, root):
        self.root = root
        self.root.geometry("800x600+300+100")
        self.root.title("Sales Reports")
        self.root.config(bg="white")

        # Title
        lbl_title = Label(self.root, text="Sales Reports", font=("Goudy old style", 25), bg="#002366", fg="white", bd=3, relief=RIDGE)
        lbl_title.pack(side=TOP, fill=X, padx=1, pady=15)

        # Create a Notebook for tabbed navigation
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill=BOTH, expand=True)

        # Sales Report Frame
        self.sales_frame = Frame(self.notebook, bg="white")
        self.notebook.add(self.sales_frame, text="Sales Report")

        # Inventory Frame
        self.inventory_frame = Frame(self.notebook, bg="white")
        self.notebook.add(self.inventory_frame, text="Inventory")

        # Initialize Sales Report UI
        self.init_sales_report()

        # Initialize Inventory UI
        self.init_inventory()

    def init_sales_report(self):
        # Frame for displaying report
        self.report_frame = Frame(self.sales_frame, bd=3, relief=RIDGE, bg="white")
        self.report_frame.pack(padx=10, pady=10, fill=BOTH, expand=True)

        # Treeview for displaying report
        self.report_tree = ttk.Treeview(self.report_frame, columns=("bill_no", "date", "customer_name", "contact", "product_name", "quantity", "net_pay"), show="headings")
        self.report_tree.pack(side=LEFT, fill=BOTH, expand=True)

        # Define headings and adjust widths
        self.report_tree.heading("bill_no", text="Bill No")
        self.report_tree.heading("date", text="Date")
        self.report_tree.heading("customer_name", text="Customer Name")
        self.report_tree.heading("contact", text="Contact")
        self.report_tree.heading("product_name", text="Product Name")
        self.report_tree.heading("quantity", text="Quantity")
        self.report_tree.heading("net_pay", text="Net Pay")

        self.report_tree.column("bill_no", width=80)
        self.report_tree.column("date", width=100)
        self.report_tree.column("customer_name", width=150)
        self.report_tree.column("contact", width=100)
        self.report_tree.column("product_name", width=150)
        self.report_tree.column("quantity", width=80)
        self.report_tree.column("net_pay", width=100)

        # Scrollbar for report
        self.scroll_y = Scrollbar(self.report_frame, orient=VERTICAL, command=self.report_tree.yview)
        self.scroll_y.pack(side=RIGHT, fill=Y)
        self.report_tree.configure(yscrollcommand=self.scroll_y.set)

        # Date selection
        lbl_start_date = Label(self.sales_frame, text="Start Date", font=("times new roman", 15), bg="white")
        lbl_start_date.pack(pady=5, anchor="w", padx=10)
        self.start_date = DateEntry(self.sales_frame, width=12, background='darkblue', foreground='white', borderwidth=2)
        self.start_date.pack(pady=5, anchor="w", padx=10)

        lbl_end_date = Label(self.sales_frame, text="End Date", font=("times new roman", 15), bg="white")
        lbl_end_date.pack(pady=5, anchor="w", padx=10)
        self.end_date = DateEntry(self.sales_frame, width=12, background='darkblue', foreground='white', borderwidth=2)
        self.end_date.pack(pady=5, anchor="w", padx=10)

        # Generate Report Button
        btn_generate = Button(self.sales_frame, text="Generate Report", command=self.generate_report, font=("times new roman", 15), bg="#2196f3", fg="white", cursor="hand2")
        btn_generate.pack(pady=10)

        # Download Report Button
        btn_download_report = Button(self.sales_frame, text="Download Report", command=self.download_report, font=("times new roman", 15), bg="#2196f3", fg="white", cursor="hand2")
        btn_download_report.pack(pady=10)

    def init_inventory(self):
        # Frame for displaying inventory
        self.inventory_display_frame = Frame(self.inventory_frame, bd=3, relief=RIDGE, bg="white")
        self.inventory_display_frame.pack(padx=10, pady=10, fill=BOTH, expand=True)

        # Treeview for displaying inventory
        self.inventory_tree = ttk.Treeview(self.inventory_display_frame, columns=("pid", "Category", "Name", "Price", "qty", "status"), show="headings")
        self.inventory_tree.pack(side=LEFT, fill=BOTH, expand=True)

        # Define headings and adjust widths
        self.inventory_tree.heading("pid", text="Product ID")
        self.inventory_tree.heading("Category", text="Category")
        self.inventory_tree.heading("Name", text="Product Name")
        self.inventory_tree.heading("Price", text="Price")
        self.inventory_tree.heading("qty", text="Quantity")
        self.inventory_tree.heading("status", text="Status")

        self.inventory_tree.column("pid", width=80)
        self.inventory_tree.column("Category", width=100)
        self.inventory_tree.column("Name", width=150)
        self.inventory_tree.column("Price", width=80)
        self.inventory_tree.column("qty", width=80)
        self.inventory_tree.column("status", width=100)

        # Scrollbar for inventory
        self.scroll_y = Scrollbar(self.inventory_display_frame, orient=VERTICAL, command =self.inventory_tree.yview)
        self.scroll_y.pack(side=RIGHT, fill=Y)
        self.inventory_tree.configure(yscrollcommand=self.scroll_y.set)

        # Load inventory data
        self.load_inventory()

        # Download Inventory Button
        btn_download_inventory = Button(self.inventory_frame, text="Download Inventory", command=self.download_inventory, font=("times new roman", 15), bg="#2196f3", fg="white", cursor="hand2")
        btn_download_inventory.pack(pady=10)

    def generate_report(self):
        # Fetch sales data from the database
        con = sqlite3.connect(database=r'ims.db')
        cur = con.cursor()
        cur.execute("PRAGMA journal_mode=WAL;")
        try:
            # Specify the columns explicitly
            cur.execute("SELECT bill_no, date, customer_name, contact, product_name, quantity, net_pay FROM sales WHERE date BETWEEN ? AND ?", 
                        (self.start_date.get_date().strftime("%d-%m-%Y"), self.end_date.get_date().strftime("%d-%m-%Y")))
            rows = cur.fetchall()
            self.report_tree.delete(*self.report_tree.get_children())  # Clear previous data

            # Debugging output
            print("Fetched rows:", rows)

            for row in rows:
                self.report_tree.insert('', END, values=row)

            if not rows:
                messagebox.showinfo("Info", "No sales found for the selected dates", parent=self.root)

        except Exception as ex:
            messagebox.showerror("Error", f"Error due to: {str(ex)}", parent=self.root)
        finally:
            con.close()

    def load_inventory(self):
        # Fetch product data from the database
        con = sqlite3.connect(database=r'ims.db')
        cur = con.cursor()
        cur.execute("PRAGMA journal_mode=WAL;")
        try:
            cur.execute("SELECT pid, Category, Name, Price, qty, status FROM product")
            rows = cur.fetchall()
            self.inventory_tree.delete(*self.inventory_tree.get_children())  # Clear previous data

            for row in rows:
                self.inventory_tree.insert('', END, values=row)

            if not rows:
                messagebox.showinfo("Info", "No products found in inventory", parent=self.root)

        except Exception as ex:
            messagebox.showerror("Error", f"Error due to: {str(ex)}", parent=self.root)
        finally:
            con.close()

    def download_report(self):
        # Fetch sales data from the database
        con = sqlite3.connect(database=r'ims.db')
        cur = con.cursor()
        cur.execute("PRAGMA journal_mode=WAL;")
        try:
            # Specify the columns explicitly
            cur.execute("SELECT bill_no, date, customer_name, contact, product_name, quantity, net_pay FROM sales WHERE date BETWEEN ? AND ?", 
                        (self.start_date.get_date().strftime("%d-%m-%Y"), self.end_date.get_date().strftime("%d-%m-%Y")))
            rows = cur.fetchall()
            columns = [desc[0] for desc in cur.description]

            # Create a pandas DataFrame
            df = pd.DataFrame(rows, columns=columns)

            # Download the report as an Excel file
            df.to_excel("Sales_Report.xlsx", index=False)

            messagebox.showinfo("Success", "Report downloaded successfully", parent=self.root)

        except Exception as ex:
            messagebox.showerror("Error", f"Error due to: {str(ex)}", parent=self.root)
        finally:
            con.close()

    def download_inventory(self):
        # Fetch product data from the database
        con = sqlite3.connect(database=r'ims.db')
        cur = con.cursor()
        cur.execute("PRAGMA journal_mode=WAL;")
        try:
            cur.execute("SELECT pid, Category, Name, Price, qty, status FROM product")
            rows = cur.fetchall()
            columns = [desc[0] for desc in cur.description]

            # Create a pandas DataFrame
            df = pd.DataFrame(rows, columns=columns)

            # Download the inventory as an Excel file
            df.to_excel("Inventory.xlsx", index=False)

            messagebox.showinfo("Success", "Inventory downloaded successfully", parent=self.root)

        except Exception as ex:
            messagebox.showerror("Error", f"Error due to: {str(ex)}", parent=self.root)
        finally:
            con.close()

if __name__ == "__main__":
    root = Tk()
    obj = ReportsClass(root)
    root.mainloop()